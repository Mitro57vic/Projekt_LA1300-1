using Microsoft.VisualBasic.Devices;
using System.Media;
using System.Windows.Forms;

namespace Pong_LA_1300
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MidX = ClientSize.Width / 2;
            MidY = ClientSize.Height / 2;
        }

        int MidX;
        int MidY;

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.Pong_LA_1300;
            PlayBTN.Visible = false;
            PlayerBar.Visible = true;
            ComBar.Visible = true;
            PongTimer.Start();
        }

        public void PlayerBar_Click(object sender, EventArgs e)
        {
            
        }

        private void ComBar_Click(object sender, EventArgs e)
        {

        }

        private void PongTimer_Tick(object sender, EventArgs e)
        {
            if (Control.ModifierKeys == Keys.Shift)
            {
                PlayerBar.Top += 25;
            }
        }
    }
}