﻿namespace Pong_LA_1300
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PlayBTN = new System.Windows.Forms.Button();
            this.PlayerBar = new System.Windows.Forms.PictureBox();
            this.ComBar = new System.Windows.Forms.PictureBox();
            this.Pongball = new System.Windows.Forms.PictureBox();
            this.PongTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pongball)).BeginInit();
            this.SuspendLayout();
            // 
            // PlayBTN
            // 
            this.PlayBTN.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PlayBTN.Location = new System.Drawing.Point(319, 313);
            this.PlayBTN.Name = "PlayBTN";
            this.PlayBTN.Size = new System.Drawing.Size(247, 67);
            this.PlayBTN.TabIndex = 0;
            this.PlayBTN.Text = "Play";
            this.PlayBTN.UseVisualStyleBackColor = true;
            this.PlayBTN.Click += new System.EventHandler(this.button1_Click);
            // 
            // PlayerBar
            // 
            this.PlayerBar.BackColor = System.Drawing.SystemColors.ControlText;
            this.PlayerBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PlayerBar.Location = new System.Drawing.Point(25, 148);
            this.PlayerBar.Name = "PlayerBar";
            this.PlayerBar.Size = new System.Drawing.Size(32, 139);
            this.PlayerBar.TabIndex = 1;
            this.PlayerBar.TabStop = false;
            this.PlayerBar.Visible = false;
            this.PlayerBar.Click += new System.EventHandler(this.PlayerBar_Click);
            // 
            // ComBar
            // 
            this.ComBar.BackColor = System.Drawing.SystemColors.ControlText;
            this.ComBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ComBar.Location = new System.Drawing.Point(819, 148);
            this.ComBar.Name = "ComBar";
            this.ComBar.Size = new System.Drawing.Size(32, 139);
            this.ComBar.TabIndex = 2;
            this.ComBar.TabStop = false;
            this.ComBar.Visible = false;
            this.ComBar.Click += new System.EventHandler(this.ComBar_Click);
            // 
            // Pongball
            // 
            this.Pongball.Location = new System.Drawing.Point(415, 192);
            this.Pongball.Name = "Pongball";
            this.Pongball.Size = new System.Drawing.Size(64, 62);
            this.Pongball.TabIndex = 3;
            this.Pongball.TabStop = false;
            // 
            // PongTimer
            // 
            this.PongTimer.Enabled = true;
            this.PongTimer.Tick += new System.EventHandler(this.PongTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pong_LA_1300.Properties.Resources.Pong_LA_1300_Mainscreen;
            this.ClientSize = new System.Drawing.Size(878, 457);
            this.Controls.Add(this.Pongball);
            this.Controls.Add(this.ComBar);
            this.Controls.Add(this.PlayerBar);
            this.Controls.Add(this.PlayBTN);
            this.Name = "Form1";
            this.Text = "Pong";
            ((System.ComponentModel.ISupportInitialize)(this.PlayerBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pongball)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Button PlayBTN;
        private PictureBox PlayerBar;
        private PictureBox ComBar;
        private PictureBox Pongball;
        private System.Windows.Forms.Timer PongTimer;
    }
}